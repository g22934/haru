from django.contrib import admin
from .models import Title, PilgrimageLocation

admin.site.register(Title)
admin.site.register(PilgrimageLocation)
