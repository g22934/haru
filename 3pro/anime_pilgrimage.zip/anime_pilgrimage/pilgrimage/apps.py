from django.apps import AppConfig


class PilgrimageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pilgrimage'
